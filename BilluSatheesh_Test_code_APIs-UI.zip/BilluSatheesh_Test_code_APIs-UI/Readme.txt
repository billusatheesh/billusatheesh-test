======================================
Service Application Running Steps Docker steps given in the Readme file inside application
======================================
Run the Application in local
Local Swagger Document URL : http://localhost:8080/swagger-ui/index.html
Not: From UI only you can search and see the match details,
=======================================
Angular Application Running Steps
=======================================
Steps To run the Application in Local
step1: run the npm install command
step2: run the ng serve or npm start command inorder run the application
step3: Access the application by http://localhost:4200
step4: You will see the login Page. Enter any user name and password and click on login button
Not: to See the data make sure you need to run server application.


Docker public image url:
==========================
docker pull billusatheesh/billusatheesh:latest